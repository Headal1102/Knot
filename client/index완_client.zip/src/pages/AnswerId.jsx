export default function AnswerId(props){

    return(
        <div>
            <h1>당신의 아이디는:</h1>
            <h1>{userId}</h1>
            <h4><span>Knot</span>/<span>로그인</span></h4>
        </div>
    )
}